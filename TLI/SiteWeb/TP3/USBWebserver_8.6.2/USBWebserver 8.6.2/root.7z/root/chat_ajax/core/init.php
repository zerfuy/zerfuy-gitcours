<?php
session_start();
define('LOGGED_IN', true);

require 'classes/Core.php';
require 'classes/Chat.php';
//include 'ChromePhp.php';